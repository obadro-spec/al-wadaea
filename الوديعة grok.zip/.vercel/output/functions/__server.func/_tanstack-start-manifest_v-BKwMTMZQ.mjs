//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BKwMTMZQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C7ph_1Cb.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C7ph_1Cb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-heCWLEqg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
