import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, i as Scale, n as TimerReset, o as Landmark, r as ShieldCheck, s as CalendarClock } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BZh8wQMh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ALBILAD = "2026-10-25";
var BOARD = "2026-10-24";
var SOURCE = {
	[ALBILAD]: "https://x.com/Diary24H/status/2114376077128708476",
	[BOARD]: "https://x.com/Diary24H/status/2114012805464457641"
};
function rows(base, rates) {
	return Object.entries(rates).map(([tenor, rate]) => ({
		...base,
		id: `${base.bank}-${base.product}-${base.min}-${tenor}`,
		tenorMonths: Number(tenor),
		rate,
		sourceUrl: SOURCE[base.asOf] ?? SOURCE[BOARD]
	}));
}
var awaed = (min, max, rates) => rows({
	bank: "البلاد",
	product: "عوائد",
	zakat: "customer",
	channel: "تطبيق",
	min,
	max,
	asOf: ALBILAD,
	ease: 3
}, rates);
var wakala = (min, max, rates) => rows({
	bank: "البلاد",
	product: "استثمار بالوكالة",
	zakat: "exempt",
	channel: "تطبيق",
	min,
	max,
	asOf: ALBILAD,
	ease: 3
}, rates);
var OFFERS = [
	...awaed(5e4, 99999.99, {
		6: 6.26,
		9: 6.36,
		12: 5.84,
		18: 5.75,
		24: 5.77
	}),
	...awaed(1e5, 999999.99, {
		1: 4.94,
		2: 5.48,
		3: 5.58,
		4: 5.68,
		6: 6.26,
		9: 6.36,
		12: 5.84,
		18: 5.75,
		24: 5.77
	}),
	...awaed(1e6, 4999999.99, {
		1: 5.04,
		2: 5.58,
		3: 5.68,
		4: 5.78,
		6: 6.36,
		9: 6.46,
		12: 5.94,
		18: 5.85,
		24: 5.88
	}),
	...awaed(5e6, Number.POSITIVE_INFINITY, {
		1: 5.14,
		2: 5.68,
		3: 5.78,
		4: 5.88,
		6: 6.46,
		9: 6.46,
		12: 6.04,
		18: 5.95,
		24: 5.98
	}),
	...wakala(5e4, 99999.99, {
		6: 5.96,
		9: 6.06,
		12: 5.54,
		18: 5.45,
		24: 5.47
	}),
	...wakala(1e5, 999999.99, {
		1: 4.64,
		2: 5.18,
		3: 5.28,
		4: 5.38,
		6: 5.96,
		9: 6.06,
		12: 5.54,
		18: 5.45,
		24: 5.47
	}),
	...wakala(1e6, 4999999.99, {
		1: 4.74,
		2: 5.28,
		3: 5.38,
		4: 5.48,
		6: 6.06,
		9: 6.06,
		12: 5.64,
		18: 5.55,
		24: 5.57
	}),
	...wakala(5e6, Number.POSITIVE_INFINITY, {
		1: 4.84,
		2: 5.38,
		3: 5.48,
		4: 5.58,
		6: 6.16,
		9: 6.16,
		12: 5.74,
		18: 5.65,
		24: 5.67
	}),
	...rows({
		bank: "الإنماء",
		product: "نماء",
		zakat: "exempt",
		channel: "تطبيق",
		min: 5e4,
		max: 199999.99,
		asOf: BOARD,
		ease: 2
	}, {
		3: 5.46,
		6: 6.18,
		9: 5.76,
		12: 5.34,
		24: 5.58,
		36: 5.62
	}),
	...rows({
		bank: "الإنماء",
		product: "نماء",
		zakat: "exempt",
		channel: "تطبيق",
		min: 2e5,
		max: 5e6,
		asOf: BOARD,
		ease: 2
	}, {
		1: 5.11,
		2: 5.29,
		3: 5.46,
		6: 6.18,
		9: 5.76,
		12: 5.34,
		24: 5.58,
		36: 5.62
	}),
	...rows({
		bank: "عز",
		product: "نماء",
		zakat: "exempt",
		channel: "تطبيق",
		min: 1e3,
		max: 49999.99,
		asOf: BOARD,
		ease: 1
	}, {
		3: 5.24,
		6: 5.93,
		9: 5.53,
		12: 5.13,
		24: 5.35,
		36: 5.39
	}),
	...rows({
		bank: "عز",
		product: "نماء",
		zakat: "exempt",
		channel: "تطبيق",
		min: 5e4,
		max: 199999.99,
		asOf: BOARD,
		ease: 1
	}, {
		3: 5.46,
		6: 6.18,
		9: 5.76,
		12: 5.34,
		24: 5.58,
		36: 5.62
	}),
	...rows({
		bank: "عز",
		product: "نماء",
		zakat: "exempt",
		channel: "تطبيق",
		min: 2e5,
		max: 5e6,
		asOf: BOARD,
		ease: 1
	}, {
		1: 5.11,
		2: 5.29,
		3: 5.46,
		6: 6.18,
		9: 5.76,
		12: 5.34,
		24: 5.58,
		36: 5.62
	}),
	...rows({
		bank: "الراجحي",
		product: "عوائد",
		zakat: "paid",
		channel: "تطبيق",
		min: 1e3,
		max: 24999.99,
		asOf: BOARD,
		ease: 2
	}, {
		3: 5.4,
		4: 5.4,
		5: 5.5,
		6: 5.5,
		7: 5.5,
		8: 5.6,
		9: 5.6,
		10: 5.6,
		11: 5.6,
		12: 5.65,
		18: 5.7,
		24: 5.75,
		30: 5.75,
		36: 5.75
	}),
	...rows({
		bank: "الراجحي",
		product: "عوائد",
		zakat: "paid",
		channel: "تطبيق",
		min: 25e3,
		max: 1e8,
		asOf: BOARD,
		ease: 2
	}, {
		1: 5,
		2: 5.2,
		3: 5.4,
		4: 5.4,
		5: 5.5,
		6: 5.5,
		7: 5.5,
		8: 5.6,
		9: 5.6,
		10: 5.6,
		11: 5.6,
		12: 5.65,
		18: 5.7,
		24: 5.75,
		30: 5.75,
		36: 5.75
	}),
	...rows({
		bank: "الأهلي",
		product: "خيرات",
		zakat: "customer",
		channel: "تطبيق",
		min: 25e3,
		max: 99999.99,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4,
		3: 4.29,
		6: 4.88,
		9: 4.97,
		12: 4.81
	}),
	...rows({
		bank: "الأهلي",
		product: "خيرات",
		zakat: "customer",
		channel: "فرع",
		min: 1e5,
		max: Number.POSITIVE_INFINITY,
		asOf: BOARD,
		ease: 0
	}, {
		1: 4.24,
		2: 4.43,
		6: 5.01,
		9: 4.95,
		12: 4.9
	}),
	...rows({
		bank: "STC",
		product: "وديعة ثابتة",
		zakat: "paid",
		channel: "تطبيق",
		min: 25e3,
		max: Number.POSITIVE_INFINITY,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.62,
		3: 5.01,
		6: 5.69,
		12: 5.14
	}),
	...rows({
		bank: "ميم",
		product: "مرابحة",
		zakat: "customer",
		channel: "تطبيق",
		min: 25e3,
		max: 2e5,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.26,
		3: 5.18,
		6: 5.86,
		12: 5.26
	}),
	...rows({
		bank: "ميم",
		product: "مرابحة",
		zakat: "customer",
		channel: "تطبيق",
		min: 200001,
		max: 5e6,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.31,
		3: 5.23,
		6: 5.91,
		12: 5.31
	}),
	...rows({
		bank: "الأول",
		product: "مرابحة بالسلع",
		zakat: "customer",
		channel: "تطبيق",
		min: 25e3,
		max: 5e6,
		asOf: BOARD,
		ease: 1
	}, {
		1: 3.5,
		2: 4.22,
		3: 4.57,
		6: 5.4,
		9: 5.4,
		12: 4.55
	}),
	...rows({
		bank: "العربي",
		product: "مرابحة",
		zakat: "customer",
		channel: "تطبيق",
		min: 5e4,
		max: 25e5,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.5,
		3: 4.92,
		6: 5.7,
		12: 4.94,
		24: 5.17
	}),
	...rows({
		bank: "العربي",
		product: "مرابحة",
		zakat: "customer",
		channel: "تطبيق",
		min: 25e5,
		max: Number.POSITIVE_INFINITY,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.63,
		3: 5.05,
		6: 5.83,
		12: 5.07,
		24: 5.3
	}),
	...rows({
		bank: "العربي",
		product: "زاد",
		zakat: "paid",
		channel: "فرع",
		min: 1e5,
		max: 999999,
		asOf: BOARD,
		ease: 0
	}, {
		3: 4.65,
		6: 4.84,
		9: 4.85,
		12: 4.9
	}),
	...rows({
		bank: "فيجن",
		product: "مرابحة",
		zakat: "customer",
		channel: "تطبيق",
		min: 1e3,
		max: Number.POSITIVE_INFINITY,
		asOf: BOARD,
		ease: 1
	}, {
		1: 4.5,
		2: 4.5,
		3: 5,
		6: 5.25,
		9: 5.5,
		12: 6
	}),
	...rows({
		bank: "الجزيرة",
		product: "نقاء",
		zakat: "customer",
		channel: "تطبيق",
		min: 4e4,
		max: 249999,
		asOf: BOARD,
		ease: 1
	}, {
		2: 4.61,
		3: 4.66,
		4: 5.16,
		6: 4.7
	}),
	...rows({
		bank: "الجزيرة",
		product: "نقاء",
		zakat: "customer",
		channel: "تطبيق",
		min: 25e4,
		max: 5e5,
		asOf: BOARD,
		ease: 1
	}, {
		2: 4.71,
		3: 4.76,
		4: 5.26,
		6: 4.8
	}),
	...rows({
		bank: "الرياض",
		product: "عائد إسلامي",
		zakat: "customer",
		channel: "فرع",
		min: 5e4,
		max: 199999,
		asOf: BOARD,
		ease: 0
	}, {
		1: 4.3,
		2: 4.4,
		3: 4.55,
		6: 4.65,
		9: 4.75,
		12: 4.75
	}),
	...rows({
		bank: "الرياض",
		product: "عائد إسلامي",
		zakat: "customer",
		channel: "فرع",
		min: 2e5,
		max: 499999,
		asOf: BOARD,
		ease: 0
	}, {
		1: 4.32,
		2: 4.42,
		3: 4.57,
		6: 4.67,
		9: 4.77,
		12: 4.77
	})
];
var ZAKAT_LABEL = {
	customer: "الزكاة عليك",
	exempt: "معفى من الزكاة",
	paid: "الزكاة مدفوعة عن فترة الاستثمار"
};
function zakatBonus(zakat, consider) {
	if (!consider || zakat === "customer") return 0;
	return 2.5;
}
function profitFor(amount, annualRate, months) {
	return amount * (annualRate / 100) * (months / 12);
}
function money(n) {
	return new Intl.NumberFormat("ar-SA-u-nu-latn", {
		minimumFractionDigits: 0,
		maximumFractionDigits: 2
	}).format(n);
}
function pct(n) {
	return `${n.toFixed(2)}%`;
}
function tenorLabel(months) {
	if (months === 1) return "شهر";
	if (months === 2) return "شهران";
	if (months <= 10) return `${months} أشهر`;
	return `${months} شهراً`;
}
var STORAGE_KEY = "wadaea-portfolio-v1";
/** Copied from the shared sheet. Two identical Izz rows are kept as two contracts. */
var SEED = [
	{
		id: "bilad-83",
		bank: "البلاد",
		months: 9,
		maturity: "2026-10-29",
		amount: 83e3,
		rate: 4.88,
		start: "2026-01-29"
	},
	{
		id: "inma-55",
		bank: "الإنماء",
		months: 6,
		maturity: "2026-12-07",
		amount: 55e3,
		rate: 5.03,
		start: "2026-06-07"
	},
	{
		id: "inma-325",
		bank: "الإنماء",
		months: 6,
		maturity: "2027-03-01",
		amount: 325e3,
		rate: 5.11,
		start: "2026-09-01"
	},
	{
		id: "bilad-50",
		bank: "البلاد",
		months: 9,
		maturity: "2027-03-22",
		amount: 5e4,
		rate: 5.04,
		start: "2026-06-22"
	},
	{
		id: "bilad-66",
		bank: "البلاد",
		months: 9,
		maturity: "2027-03-25",
		amount: 66500,
		rate: 5.04,
		start: "2026-06-25"
	},
	{
		id: "izz-6",
		bank: "عز",
		months: 6,
		maturity: "2027-03-28",
		amount: 6e3,
		rate: 5.08,
		start: "2026-09-28"
	},
	{
		id: "bilad-77",
		bank: "البلاد",
		months: 9,
		maturity: "2027-07-22",
		amount: 77780,
		rate: 6.06,
		start: "2026-10-22"
	},
	{
		id: "izz-5a",
		bank: "عز",
		months: 6,
		maturity: "2027-04-27",
		amount: 5e3,
		rate: 5.58,
		start: "2026-10-27"
	},
	{
		id: "izz-5b",
		bank: "عز",
		months: 6,
		maturity: "2027-04-27",
		amount: 5e3,
		rate: 5.58,
		start: "2026-10-27"
	}
];
function parseISODate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return Date.UTC(y, (m ?? 1) - 1, d ?? 1);
}
function daysBetween(from, to) {
	return Math.round((parseISODate(to) - parseISODate(from)) / 864e5);
}
function riyadhToday(now = /* @__PURE__ */ new Date()) {
	return new Intl.DateTimeFormat("en-CA", {
		timeZone: "Asia/Riyadh",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).format(now);
}
function formatDay(iso) {
	const dt = new Date(parseISODate(iso));
	return new Intl.DateTimeFormat("ar-SA-u-nu-latn", {
		day: "numeric",
		month: "long",
		year: "numeric",
		timeZone: "UTC"
	}).format(dt);
}
function leftLabel(days) {
	if (days < 0) return `مضى منذ ${Math.abs(days)} يوم`;
	if (days === 0) return "تستحق اليوم";
	if (days === 1) return "تستحق غداً";
	if (days === 2) return "بعد يومين";
	if (days <= 10) return `بعد ${days} أيام`;
	return `بعد ${days} يوماً`;
}
function viewContract(deposit, today) {
	const totalDays = Math.max(1, daysBetween(deposit.start, deposit.maturity));
	const elapsed = Math.min(totalDays, Math.max(0, daysBetween(deposit.start, today)));
	const left = daysBetween(today, deposit.maturity);
	const profit = deposit.amount * (deposit.rate / 100) * (deposit.months / 12);
	const accrued = profit * (elapsed / totalDays);
	return {
		deposit,
		totalDays,
		elapsed,
		left,
		profit,
		accrued,
		remaining: Math.max(0, profit - accrued),
		atMaturity: deposit.amount + profit
	};
}
function offersFor(amount, tenor) {
	return OFFERS.filter((offer) => {
		if (amount < offer.min || amount > offer.max) return false;
		if (tenor !== "auto" && offer.tenorMonths !== tenor) return false;
		return true;
	});
}
function rankOffers(amount, tenor, considerZakat) {
	const ranked = offersFor(amount, tenor).map((offer) => ({
		...offer,
		effective: offer.rate + zakatBonus(offer.zakat, considerZakat),
		profit: profitFor(amount, offer.rate, offer.tenorMonths)
	}));
	ranked.sort((a, b) => {
		if (b.effective !== a.effective) return b.effective - a.effective;
		if (b.ease !== a.ease) return b.ease - a.ease;
		if (a.tenorMonths !== b.tenorMonths) return a.tenorMonths - b.tenorMonths;
		return b.rate - a.rate;
	});
	return ranked;
}
/** Diary24H ignores gaps as small as 0.15 point when the bank is convenient. */
var TIE = .15;
function pickOffer(ranked, homeBank) {
	if (!ranked.length) return null;
	const best = ranked[0];
	const band = ranked.filter((offer) => best.effective - offer.effective <= TIE);
	band.sort((a, b) => {
		const aHome = a.bank === homeBank ? 1 : 0;
		const bHome = b.bank === homeBank ? 1 : 0;
		if (bHome !== aHome) return bHome - aHome;
		if (b.ease !== a.ease) return b.ease - a.ease;
		const aSweet = a.tenorMonths === 6 || a.tenorMonths === 9 ? 1 : 0;
		const bSweet = b.tenorMonths === 6 || b.tenorMonths === 9 ? 1 : 0;
		if (bSweet !== aSweet) return bSweet - aSweet;
		if (b.rate !== a.rate) return b.rate - a.rate;
		return a.tenorMonths - b.tenorMonths;
	});
	return band[0] ?? best;
}
function advise(deposit, today, considerZakat) {
	const view = viewContract(deposit, today);
	const rollAmount = Math.round(view.atMaturity * 100) / 100;
	const ranked = rankOffers(rollAmount, "auto", considerZakat);
	const pick = pickOffer(ranked, deposit.bank);
	const alt = ranked.find((offer) => offer.id !== pick?.id && offer.bank !== pick?.bank) ?? ranked.find((offer) => offer.id !== pick?.id) ?? null;
	if (!pick) return {
		view,
		action: "hold",
		headline: "لا توجد شريحة مطابقة لهذا المبلغ في الجدول",
		detail: "ارفع المبلغ إلى الحد الأدنى أو أبقه في البنك الحالي.",
		pick: null,
		alt: null,
		rollAmount
	};
	if (view.left <= 1) return {
		view,
		action: "reinvest",
		headline: `أعِد المبلغ في نفس اليوم إلى ${pick.bank} — ${pick.product}`,
		detail: sameDayDetail(pick, alt, rollAmount),
		pick,
		alt,
		rollAmount
	};
	if (view.left <= 45) return {
		view,
		action: "roll-soon",
		headline: "لا تكسر العقد. جهّز إعادة الاستثمار ليوم الاستحقاق",
		detail: holdDetail(view, pick, false),
		pick,
		alt,
		rollAmount
	};
	const grossGap = Math.max(0, pick.rate - deposit.rate);
	const opportunity = deposit.amount * (grossGap / 100) * (Math.max(view.left, 0) / 365);
	if (opportunity > view.remaining && grossGap >= .8) return {
		view,
		action: "reinvest",
		headline: "الفارق أكبر من الربح المتبقي — اسأل البنك عن كسر العقد قبل أن تتحرك",
		detail: `الربح المتبقي تقريباً ${Math.round(view.remaining)} ريال، بينما فارق النسبة حتى الاستحقاق حوالي ${Math.round(opportunity)} ريال. بعض البنوك تُسقط الربح كله عند الكسر.`,
		pick,
		alt,
		rollAmount
	};
	return {
		view,
		action: "hold",
		headline: "أبقِ العقد حتى الاستحقاق",
		detail: holdDetail(view, pick, true),
		pick,
		alt,
		rollAmount
	};
}
function sameDayDetail(pick, alt, amount) {
	const altText = alt ? ` البديل القريب: ${alt.bank} ${alt.product} ${alt.tenorMonths} شهر عند ${alt.rate.toFixed(2)}%.` : "";
	return `على مبلغ ${Math.round(amount).toLocaleString("en-US")} ريال، النسبة المنشورة ${pick.rate.toFixed(2)}% لمدة ${pick.tenorMonths} شهراً. ألغِ التجديد التلقائي، وتأكد من الرقم داخل التطبيق صباح التنفيذ لأن الجدول يتغير.${altText}`;
}
function holdDetail(view, pick, far) {
	const gap = pick.rate - view.deposit.rate;
	return `${far ? "كسر العقد الآن غالباً يضيع ربحاً تحقق أكثر مما ستكسبه من فرق النسبة في الأيام المتبقية." : "الأيام القليلة لا تبرر الكسر. كل يوم بلا عقد بعد الاستحقاق ربح فائت."} عند الاستحقاق قارن ما يظهر في التطبيق مع ${pick.bank} ${pick.product} ${pick.rate.toFixed(2)}% لمدة ${pick.tenorMonths} شهر. فرق النسبة اليوم عن عقدك حوالي ${gap.toFixed(2)} نقطة، والعقد القائم لا يتأثر بانخفاض النسب الجديدة.`;
}
var TENORS = [
	1,
	3,
	6,
	9,
	12,
	24
];
function Advisor() {
	const [today, setToday] = (0, import_react.useState)("2026-10-28");
	const [deposits, setDeposits] = (0, import_react.useState)(SEED);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [zakatOn, setZakatOn] = (0, import_react.useState)(true);
	const [selectedId, setSelectedId] = (0, import_react.useState)(SEED[0].id);
	const [tenor, setTenor] = (0, import_react.useState)("auto");
	const [amountText, setAmountText] = (0, import_react.useState)("86038");
	(0, import_react.useEffect)(() => {
		const tick = () => setToday(riyadhToday());
		tick();
		const id = window.setInterval(tick, 6e4);
		const onVisible = () => {
			if (document.visibilityState === "visible") tick();
		};
		document.addEventListener("visibilitychange", onVisible);
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed) && parsed.length) setDeposits(parsed);
			}
		} catch {}
		setReady(true);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVisible);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(deposits));
	}, [deposits, ready]);
	const advices = (0, import_react.useMemo)(() => deposits.map((deposit) => advise(deposit, today, zakatOn)).sort((a, b) => a.view.left - b.view.left), [
		deposits,
		today,
		zakatOn
	]);
	const selected = advices.find((item) => item.view.deposit.id === selectedId) ?? advices[0];
	(0, import_react.useEffect)(() => {
		if (selected) setAmountText(String(Math.round(selected.rollAmount)));
	}, [
		selectedId,
		today,
		zakatOn,
		deposits
	]);
	const amount = Number(amountText.replace(/[^\d.]/g, "")) || 0;
	const ladder = (0, import_react.useMemo)(() => rankOffers(amount, tenor, zakatOn).slice(0, 6), [
		amount,
		tenor,
		zakatOn
	]);
	const principal = deposits.reduce((sum, item) => sum + item.amount, 0);
	const bookProfit = advices.reduce((sum, item) => sum + item.view.profit, 0);
	const daily = advices.reduce((sum, item) => {
		const days = Math.max(1, item.view.deposit.months * 30);
		return sum + item.view.profit / days;
	}, 0);
	const weighted = principal === 0 ? 0 : deposits.reduce((sum, item) => sum + item.amount * item.rate, 0) / principal;
	const urgent = advices.find((item) => item.view.left <= 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 pb-16 pt-6 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium tracking-wide text-gold",
						children: [
							"تحديث يومي · ",
							formatDay(today),
							" · جداول @Diary24H"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl leading-none text-ink",
						children: "مرشد الوديعة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted",
						children: "يرتّب عقودك بتاريخ الاستحقاق، ويقترح البنك والمنتج من آخر نسب منشورة: البلاد في 25 أكتوبر 2026 وبقية البنوك في 24 أكتوبر."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setDeposits(SEED);
						setSelectedId(SEED[0].id);
						localStorage.removeItem(STORAGE_KEY);
					},
					className: "inline-flex shrink-0 items-center gap-2 rounded-full border border-line bg-surface px-3 py-2 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "الجدول الأصلي"]
				})]
			}),
			urgent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-5 rounded-2xl border border-copper/30 bg-copper-soft p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-semibold text-copper",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerReset, { className: "size-4" }),
							leftLabel(urgent.view.left),
							" · ",
							formatDay(urgent.view.deposit.maturity)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl leading-snug text-ink",
						children: urgent.headline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-3xl text-sm text-ink/90",
						children: urgent.detail
					}),
					urgent.pick && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "المنتج",
								v: `${urgent.pick.bank} · ${urgent.pick.product}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "النسبة والمدة",
								v: `${pct(urgent.pick.rate)} · ${tenorLabel(urgent.pick.tenorMonths)}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "تاريخ التوصية",
								v: formatDay(urgent.pick.asOf)
							})
						]
					}),
					urgent.pick && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TweetLink, {
						href: urgent.pick.sourceUrl,
						className: "mt-3"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "أصل الودائع",
						value: `${money(principal)} ر.س`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "ربح العقود",
						value: `${money(bookProfit)} ر.س`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "ربح يومي تقريبي",
						value: `${money(daily)} ر.س`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "متوسط النسبة",
						value: pct(weighted)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "عقودك بالأولوية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZakatToggle, {
						on: zakatOn,
						setOn: setZakatOn
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-3",
					children: advices.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DepositCard, {
						advice: item,
						today,
						active: item.view.deposit.id === selected?.view.deposit.id,
						onSelect: () => setSelectedId(item.view.deposit.id)
					}) }, item.view.deposit.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "سلّم المقارنة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "نفس المبلغ على الشرائح المنشورة. الترتيب يضيف 2.5 نقطة تقديرية للمعفى ومدفوع الزكاة إذا كان الاعتبار مفعّلاً."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted",
							children: ["المبلغ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								inputMode: "decimal",
								value: amountText,
								onChange: (event) => setAmountText(event.target.value),
								className: "mt-1 block w-36 rounded-lg border border-line bg-bg px-3 py-2 text-sm text-ink tabular-nums"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2 overflow-x-auto pb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: tenor === "auto",
							onClick: () => setTenor("auto"),
							children: "كل المدد"
						}), TENORS.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
							active: tenor === value,
							onClick: () => setTenor(value),
							children: tenorLabel(value)
						}, value))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 divide-y divide-line",
						children: [ladder.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-6 text-sm text-muted",
							children: "لا توجد شريحة لهذا المبلغ والمدة."
						}), ladder.map((offer, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LadderRow, {
							offer,
							place: index + 1,
							max: ladder[0]?.effective ?? 1
						}, offer.id))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Principle, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }),
						title: "المعفى أولاً",
						body: "منهج الحساب: استثمار بالوكالة في البلاد، أو نماء الإنماء وعز. فرق 0.15 نقطة لا يستحق نقل البنك."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Principle, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-4" }),
						title: "لا تجديد تلقائي",
						body: "النسبة التي يُنشأ بها العقد هي ربحك. العقد القائم لا ينقص إذا نزلت نسب اليوم التالي."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Principle, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "size-4" }),
						title: "لا تكسر لفرق صغير",
						body: "أسهل كسر عنده: البلاد ثم الراجحي ثم الإنماء. لا تترك يوماً بعد الاستحقاق بلا عقد."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs leading-relaxed text-faint",
				children: "ليست استشارة استثمارية ولا فتوى زكاة. الأرقام منقولة من صور حساب @Diary24H العامة وقد تتغير في اليوم نفسه. الزكاة 2.5% هنا قاعدة ترتيب نشرها الحساب، لا احتساب شرعي لحولك. تأكد من الحد الأدنى ونص العقد داخل التطبيق قبل التحويل."
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface/80 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-0.5 text-sm font-semibold text-ink",
			children: v
		})]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-lg font-semibold tabular-nums text-ink",
			children: value
		})]
	});
}
function ZakatToggle({ on, setOn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick: () => setOn(!on),
		className: "inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3 py-2 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${on ? "bg-pine" : "bg-line"}` }), on ? "أُفضّل المعفى من الزكاة" : "أقارن النسبة الإجمالية فقط"]
	});
}
function Chip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `shrink-0 rounded-full px-3 py-2 text-xs ${active ? "bg-pine text-pine-ink" : "bg-surface-2 text-ink"}`,
		children
	});
}
var ACTION_STYLE = {
	reinvest: "bg-copper text-pine-ink",
	"roll-soon": "bg-gold text-pine-ink",
	hold: "bg-surface-2 text-hold"
};
var ACTION_WORD = {
	reinvest: "نفّذ",
	"roll-soon": "جهّز",
	hold: "أبقِ"
};
function DepositCard({ advice, today, active, onSelect }) {
	const { deposit } = advice.view;
	const pick = advice.pick;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "button",
		tabIndex: 0,
		onClick: onSelect,
		onKeyDown: (event) => {
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				onSelect();
			}
		},
		className: `w-full rounded-2xl border bg-surface p-4 text-start ${active ? "border-pine" : "border-line"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4 text-pine" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: deposit.bank
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded-full px-2 py-0.5 text-xs ${ACTION_STYLE[advice.action]}`,
							children: ACTION_WORD[advice.action]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: advice.headline
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold tabular-nums",
						children: leftLabel(advice.view.left)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-faint",
						children: formatDay(deposit.maturity)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
						k: "المبلغ",
						v: `${money(deposit.amount)} ر.س`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
						k: "نسبتك",
						v: pct(deposit.rate)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
						k: "الربح المتوقع",
						v: `${money(advice.view.profit)} ر.س`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pair, {
						k: "المدة",
						v: tenorLabel(deposit.months)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-xl border border-line bg-surface-2 px-3 py-2",
				children: pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-gold",
						children: ["توصية ", formatDay(pick.asOf)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm font-semibold text-ink",
						children: [
							pick.bank,
							" — ",
							pick.product,
							" — ",
							tenorLabel(pick.tenorMonths),
							" — ",
							pct(pick.rate)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: [
							ZAKAT_LABEL[pick.zakat],
							" · الأيام حُدّثت ",
							formatDay(today)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TweetLink, {
						href: pick.sourceUrl,
						className: "mt-1"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["لا توصية لهذا المبلغ في جدول ", formatDay(today)]
				})
			})
		]
	});
}
function TweetLink({ href, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noreferrer",
		onClick: (event) => event.stopPropagation(),
		className: `inline-flex text-xs font-medium text-pine underline ${className ?? ""}`,
		children: "رابط التغريدة"
	});
}
function Pair({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-bg px-2 py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-faint",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-medium tabular-nums text-ink",
			children: v
		})]
	});
}
function LadderRow({ offer, place, max }) {
	const width = Math.max(8, Math.round(offer.effective / max * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "grid grid-cols-[1.5rem_1fr] gap-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pt-0.5 text-sm text-faint tabular-nums",
			children: place
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm font-semibold",
					children: [offer.bank, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-normal text-muted",
						children: [" · ", offer.product]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-semibold tabular-nums text-pine",
					children: pct(offer.rate)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-pine",
					style: { width: `${width}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					tenorLabel(offer.tenorMonths),
					" · ",
					ZAKAT_LABEL[offer.zakat],
					" · جدول ",
					formatDay(offer.asOf),
					" · ربح",
					" ",
					money(offer.profit),
					" ر.س",
					offer.zakat !== "customer" ? ` · ترتيب ${offer.effective.toFixed(2)}` : ""
				]
			})
		] })]
	});
}
function Principle({ icon, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-sm font-semibold text-pine",
			children: [icon, title]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: body
		})]
	});
}
var SplitComponent = Advisor;
//#endregion
export { SplitComponent as component };
